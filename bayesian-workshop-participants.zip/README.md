# Bayesian decisions: how much do you trust your prediction?

A model can give you a prediction without telling you how much evidence supports it. If you are going to act on that prediction, that distinction matters. Would you play a slot machine after watching it win three times?

In this workshop, you will explore those questions through a Python exercise. You will compare beliefs that describe a range of possible outcomes, see how their predictions depend on your assumptions, and use them to make decisions. Along the way, you will look for reasons to question your own results.

You do not need any previous experience with Bayesian methods. If you are comfortable with Python and have worked with AI or machine learning, you have what you need to get started. The notebook introduces the ideas as you use them and include working code for each step.

## Working with your team

Work in a team of two or three. One person can drive the notebook while the others interpret the results and question the choices you are making. Swap roles as you go. You can share a laptop, or run your own copies to compare different assumptions.

AI coding assistants are welcome. They can help explain unfamiliar code, make changes, and investigate unexpected results. Before asking an agent to change something, take a moment to predict what you think will happen. Afterward, check whether the result makes sense to your team. For example:

> “We think a stronger prior will have more influence on our estimate when we have fewer observations. Help us change the prior and compare the results.”

The goal is to leave with a decision you can explain. A useful question to keep asking each other is: **What would make us change our minds?**

## The Bayesian Casino

You are sitting in front of one slot machine with a fixed, unknown chance of winning. Choose a starting belief, reveal its results a few plays at a time, and see how your knowledge changes.

Each play costs one token. A win returns 2.4 tokens in total, so you gain 1.4 tokens on a winning play and lose one token on a losing play. These are fictional tokens.

Your starting belief is called a **prior**. You can choose a broad prior, a mild house-edge prior, or a stronger “Las Vegas” prior. All three use a Beta distribution to describe possible win probabilities. The Las Vegas name is an illustration, not a claim about real casino odds.

Start with five plays, then reveal 20, 100, and 500 plays from the same run. Combine your prior with the observations to get your **posterior**, your updated belief about the machine's win probability. Compare the three priors and watch how much uncertainty remains as the evidence grows.

Use the posterior to predict the next 100 plays and decide whether you would keep playing. Even when you become confident about the machine's win probability, future wins and losses remain random.

An additional section introduces NUTS, a sampling method based on Hamiltonian Monte Carlo. Compare its samples with the exact posterior you have already calculated, so you have a way to check the result.

Open [the casino notebook](notebooks/01_casino.ipynb) to begin.

## Getting the notebook running

You will need Python **3.11 or 3.12**. If you downloaded a ZIP, extract it first. Open a terminal in the extracted folder—the one containing this README and `requirements.txt`.

On macOS or Linux, run:

```sh
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m jupyterlab
```

If you use Python 3.12, replace `python3.11` in the first command with `python3.12`.

On Windows, using PowerShell, run:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m jupyterlab
```

For Python 3.12, use `py -3.12` in the first command. If PowerShell blocks activation, you can run the environment's Python directly:

```powershell
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m jupyterlab
```

These commands create a separate Python environment, install the packages, and open JupyterLab in your browser. In JupyterLab, open the `notebooks` folder and start with `01_casino.ipynb`. You can run each cell with **Shift+Enter**. Work from top to bottom, since later cells use results from earlier ones.

If you prefer VS Code, you can open the notebook there instead. Select the Python environment in `.venv` as the notebook kernel.

Try to install the packages and run the first setup cell before the session. Installation requires internet access; the datasets are already included in your download.

## If something takes a while or goes wrong

The first casino model fit can take a few minutes because PyMC needs to prepare the calculations before sampling. Later fits may be faster.

If you need to keep moving, find `USE_CACHED = False` in the casino notebook and change it to `True`. This loads a fit for the Mild house edge prior after the first five plays. A different prior or number of observed plays requires a new fit with `USE_CACHED = False`.

If Python says a package is missing, check that your notebook is using the same `.venv` environment where you installed the packages. If you have run cells out of order and the results seem inconsistent, restart the notebook kernel and run the cells again from the top.

The notebook has optional extensions. It is fine to finish the main exercise first and return to those if you have time. Aim to explain what you chose, what evidence supported it, and which assumption you would want to investigate next.
